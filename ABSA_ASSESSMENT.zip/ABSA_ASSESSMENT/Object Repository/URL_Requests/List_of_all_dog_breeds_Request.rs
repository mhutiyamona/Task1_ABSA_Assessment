<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>Perform an API request to produce a list of all dog breeds.</description>
   <name>List_of_all_dog_breeds_Request</name>
   <tag></tag>
   <elementGuidId>b898e765-b451-49c4-953a-169326743e98</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>GET</restRequestMethod>
   <restUrl>https://dog.ceo/api/breeds/list/all</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
