import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import internal.GlobalVariable as GlobalVariable

Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/ABSA_Testsuite/AbsaAssessmentTestsuite')

suiteProperties.put('name', 'AbsaAssessmentTestsuite')

suiteProperties.put('description', '- Perform an API request to produce a list of all dog breeds. \r\n- Using code, verify \u201Cretriever\u201D breed is within the list. \r\n- Perform an API request to produce a list of sub-breeds for \u201Cretriever\u201D. \r\n- Perform an API request to produce a random image / link for the sub-   breed \u201Cgolden\u201D')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())



RunConfiguration.setExecutionSettingFile("C:\\Users\\HP\\Katalon Studio\\ABSA_ASSESSMENT\\Reports\\ABSA_Testsuite\\AbsaAssessmentTestsuite\\20181127_101120\\execution.properties")

TestCaseMain.beforeStart()

TestCaseMain.startTestSuite('Test Suites/ABSA_Testsuite/AbsaAssessmentTestsuite', suiteProperties, [new TestCaseBinding('Test Cases/ABSA_Testcase/verify_list_of_all_dog_breeds', 'Test Cases/ABSA_Testcase/verify_list_of_all_dog_breeds',  null), new TestCaseBinding('Test Cases/ABSA_Testcase/verify_list_of_sub-breeds', 'Test Cases/ABSA_Testcase/verify_list_of_sub-breeds',  null), new TestCaseBinding('Test Cases/ABSA_Testcase/verify_random_image_link_for_golden', 'Test Cases/ABSA_Testcase/verify_random_image_link_for_golden',  null), new TestCaseBinding('Test Cases/ABSA_Testcase/verify_Retriever_breed_is_within_the_list', 'Test Cases/ABSA_Testcase/verify_Retriever_breed_is_within_the_list',  null)])
