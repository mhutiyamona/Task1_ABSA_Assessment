<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>- Perform an API request to produce a list of all dog breeds. 
- Using code, verify “retriever” breed is within the list. 
- Perform an API request to produce a list of sub-breeds for “retriever”. 
- Perform an API request to produce a random image / link for the sub-   breed “golden”</description>
   <name>AbsaAssessmentTestsuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-27T10:11:20</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f424c69e-ca10-4484-942c-949108789991</testSuiteGuid>
   <testCaseLink>
      <guid>2b917015-d180-4a05-95a5-a25709b9fa0e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ABSA_Testcase/verify_list_of_all_dog_breeds</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c2416cf4-8af0-4167-b474-de59cf342726</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ABSA_Testcase/verify_list_of_sub-breeds</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6adb51fb-5e6f-44fc-af40-b179b38e2e70</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ABSA_Testcase/verify_random_image_link_for_golden</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>21b2ff09-8a5b-481d-b912-fdedeb68b01a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ABSA_Testcase/verify_Retriever_breed_is_within_the_list</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
