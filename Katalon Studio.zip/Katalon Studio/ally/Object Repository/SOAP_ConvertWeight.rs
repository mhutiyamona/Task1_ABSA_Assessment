<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>SOAP_ConvertWeight</name>
   <tag></tag>
   <elementGuidId>6d2a3dfe-5d69-4e14-bd0c-7deb3691bdb3</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <restRequestMethod></restRequestMethod>
   <restUrl></restUrl>
   <serviceType>SOAP</serviceType>
   <soapBody>&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot;?>
&lt;soap:Envelope xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xmlns:xsd=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:soap=&quot;http://schemas.xmlsoap.org/soap/envelope/&quot;>
  &lt;soap:Body>
    &lt;ConvertWeight xmlns=&quot;http://www.webserviceX.NET/&quot;>
      &lt;Weight>3&lt;/Weight>
      &lt;FromUnit>Kilograms&lt;/FromUnit>
      &lt;ToUnit>Grams&lt;/ToUnit>
    &lt;/ConvertWeight>
  &lt;/soap:Body>
&lt;/soap:Envelope></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod>POST</soapRequestMethod>
   <soapServiceFunction>ConvertWeight</soapServiceFunction>
   <wsdlAddress>http://www.webservicex.net/ConvertWeight.asmx?WSDL</wsdlAddress>
</WebServiceRequestEntity>
