<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>ABSA</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-22T15:46:17</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>be5d332d-a79e-4d0d-98ae-ee36be219d4c</testSuiteGuid>
   <testCaseLink>
      <guid>2918edd5-a17d-457f-a0f1-855e37f80a07</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/assessment testcase/list of breed</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>039598a3-6624-427d-87c8-99db579b80f7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/assessment testcase/verify the retrieve</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f8ca3103-5b61-48d0-ba35-24575eb106b6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/assessment testcase/verify image for golden</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c32fafe3-6cef-479d-a0a0-ae65505926a7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/assessment testcase/verify Sub-breeds</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
